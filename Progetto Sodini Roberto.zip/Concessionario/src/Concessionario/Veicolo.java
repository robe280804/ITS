package Concessionario;

public class Veicolo {

    //static because is common for all classes
    private static int numeroVeicoli;
    private boolean accensione = false;

    private double serbatoio;
    private double MaxSerbatoio = 50.0;

    private String marca;
    private String modello;
    private int anno;
    double cilindrata;
    private double prezzo;

    public Veicolo(String marca, String modello, int anno, double cilindrata, double prezzo) {
        this.marca = marca;
        this.modello = modello;
        this.anno = anno;
        this.cilindrata = cilindrata;
        this.prezzo = prezzo;
        this.serbatoio = 0.00;


        //number of istance
        numeroVeicoli++;
    }

    public static int numeroVeicoli() {
        return numeroVeicoli;
    }

    public String getTipo() {
        return marca;
    }

    public String getModello() {
        return modello;
    }

    public int getAnno() {
        return anno;
    }

    public double getCilindrata() {
        return cilindrata;
    }

    public double getPrezzo(){
        return prezzo;
    }


    public String toString() {
        return "Veicolo {Marca: " + marca + ", modello: " + modello + ", anno: " + anno + ", cilindrata: " + cilindrata + ", prezzo: " + prezzo + "}";
    }

    public boolean Accendi(){
        if (accensione != false){
            throw new IllegalStateException("il veicolo è già acceso");
        } else {
            accensione = true;
            return true;
        }
    }

    public boolean Spegni() {
        if (accensione == false) {
            throw new IllegalStateException("il veicolo è già spento");
        } else {
            accensione = true;
            return true;
        }
    }

    public void faiBenzina( double litri){
            if (serbatoio + litri > MaxSerbatoio) {
                throw new IllegalStateException("troppi litri, serbatoio: " + serbatoio);
            }
            try {
                serbatoio += litri;
                System.out.println("Serbatoio : " + serbatoio + " litri");
            } catch (Exception e){
                System.out.println("Error: " + e.getMessage());
            }
        }


}
