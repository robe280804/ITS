package Concessionario;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        Utente utente = new Utente("Roberto");
        utente.setSaldo(10000000);

        Concessionario ConcessionarioBMW = new Concessionario();
        Concessionario ConcessionarioAUDI = new Concessionario();
        Concessionario ConcessionarioMERCEDES = new Concessionario();
        Concessionario ConcessionarioGUIDI = new Concessionario();


        Automobile auto1 = new Automobile("BMW ", "M4", 2022, 2900.00, 44500.00, 5, "benzina");
        Automobile auto2 = new Automobile("Mercedes", "AMG 63s ", 2024, 3000.00, 60230.00, 5, "benzina");
        Automobile auto3 = new Automobile("BMW", "M1", 2012, 2500.00, 22500.00, 5, "diesel");
        Automobile auto4 = new Automobile("Audi", "RS7", 2023, 4000.00, 115000.00, 5, "benzina");
        Automobile auto5 = new Automobile("Porsche", "911 Carrera S", 2023, 3000.00, 120000.00, 4, "benzina");
        Automobile auto6 = new Automobile("Tesla", "Model S Plaid", 2022, 0.00, 129990.00, 5, "elettrico");
        Automobile auto7 = new Automobile("Ferrari", "F8 Tributo", 2022, 3900.00, 300000.00, 2, "benzina");
        Automobile auto8 = new Automobile("Lamborghini", "Huracan EVO", 2023, 5200.00, 265000.00, 2, "benzina");
        Automobile auto9 = new Automobile("BMW", "X5 M", 2023, 4400.00, 104000.00, 5, "benzina");
        Automobile auto10 = new Automobile("Ford", "Mustang Shelby GT500", 2022, 5000.00, 74500.00, 4, "benzina");
        Automobile auto11 = new Automobile("Chevrolet", "Corvette Stingray", 2023, 6200.00, 64900.00, 2, "benzina");
        Automobile auto12 = new Automobile("Mercedes", "E-Class", 2023, 3000.00, 60000.00, 5, "diesel");
        Automobile auto13 = new Automobile("Mercedes", "GLC 300", 2024, 2000.00, 56000.00, 5, "benzina");
        Automobile auto14 = new Automobile("Mercedes", "S-Class", 2023, 4000.00, 115000.00, 5, "benzina");

        Moto moto1 = new Moto("KTM", "Duke 390", 2023, 373, 5000.00, 2);
        Moto moto2 = new Moto("Yamaha", "YZF-R1", 2023, 998, 17000.00, 2);
        Moto moto3 = new Moto("Honda", "CBR1000RR-R", 2022, 1000, 27000.00, 2);
        Moto moto4 = new Moto("Ducati", "Panigale V4", 2023, 1103, 23000.00, 2);
        Moto moto5 = new Moto("Suzuki", "GSX-R1000", 2023, 999, 16000.00, 2);
        Moto moto6 = new Moto("BMW", "S1000RR", 2023, 999, 23000.00, 2);
        Moto moto7 = new Moto("Kawasaki", "Ninja ZX-10R", 2023, 998, 18000.00, 2);
        Moto moto8 = new Moto("Triumph", "Street Triple RS", 2023, 765, 14000.00, 2);

        ConcessionarioBMW.aggiungiVeicolo(auto1);
        ConcessionarioBMW.aggiungiVeicolo(auto3);
        ConcessionarioBMW.aggiungiVeicolo(auto9);
        ConcessionarioBMW.aggiungiVeicolo(moto6);

        ConcessionarioMERCEDES.aggiungiVeicolo(auto2);
        ConcessionarioMERCEDES.aggiungiVeicolo(auto12);
        ConcessionarioMERCEDES.aggiungiVeicolo(auto13);
        ConcessionarioMERCEDES.aggiungiVeicolo(auto14);

        ConcessionarioAUDI.aggiungiVeicolo(auto4);

        ConcessionarioGUIDI.aggiungiVeicolo(auto5);
        ConcessionarioGUIDI.aggiungiVeicolo(auto6);
        ConcessionarioGUIDI.aggiungiVeicolo(auto7);
        ConcessionarioGUIDI.aggiungiVeicolo(auto8);
        ConcessionarioGUIDI.aggiungiVeicolo(auto10);
        ConcessionarioGUIDI.aggiungiVeicolo(auto11);

        ConcessionarioGUIDI.aggiungiVeicolo(moto1);
        ConcessionarioGUIDI.aggiungiVeicolo(moto2);
        ConcessionarioGUIDI.aggiungiVeicolo(moto3);
        ConcessionarioGUIDI.aggiungiVeicolo(moto4);
        ConcessionarioGUIDI.aggiungiVeicolo(moto5);
        ConcessionarioGUIDI.aggiungiVeicolo(moto7);
        ConcessionarioGUIDI.aggiungiVeicolo(moto8);


        //Funzionnamento Progamma
        System.out.println("Benvenuto " + utente.getNome());

        Scanner scanner = new Scanner(System.in);
        int scelta =  0;
        while (scelta != 5){
            System.out.println("\nMenu:");
            System.out.println("1. Concessionario BMW");
            System.out.println("2. Concessionario AUDI");
            System.out.println("3. Concessionario MERCEDES");
            System.out.println("4. Concessionario GUIDI");
            System.out.println("5. Carica Saldo Utente");
            System.out.println("6. Compra Macchina");
            System.out.println("7. Visualizza Garage");
            System.out.println("8. Esci");
            System.out.print("Scegli un'opzione: ");
            scelta = scanner.nextInt();
            scanner.nextLine();

            switch(scelta){
                case 1:
                    menuConcessionario(ConcessionarioBMW, scanner);
                    break;
                case 2:
                    menuConcessionario(ConcessionarioAUDI, scanner);
                    break;
                case 3:
                    menuConcessionario(ConcessionarioMERCEDES, scanner);
                    break;
                case 4:
                    menuConcessionario(ConcessionarioGUIDI, scanner);
                    break;
                case 5:
                    caricaSaldo(utente, scanner);
                    break;
                case 6:
                    System.out.println("Da quale concessionario vuoi comprare? (BMW/MERCEDES/AUDI/GUIDI)");
                    String concessionario = scanner.nextLine().toLowerCase();

                    switch (concessionario){
                        case "bmw":
                            compraMacchina(utente, ConcessionarioBMW, scanner);
                            break;
                        case "audi":
                            compraMacchina(utente, ConcessionarioAUDI, scanner);
                            break;
                        case "mercedes":
                            compraMacchina(utente, ConcessionarioMERCEDES, scanner);
                            break;
                        case "guidi":
                            compraMacchina(utente, ConcessionarioGUIDI, scanner);
                            break;
                    }

                case 7:
                    utente.mostraGarage();
                    break;
                case 8:
                    break;
            }

        }
    }

    public static void menuConcessionario(Concessionario concessionario, Scanner scanner){
        int opzione = 0;
        while (opzione != 8){
            System.out.println("\nOperazioni disponibili:");
            System.out.println("1. Mostra veicoli");
            System.out.println("2. Aggiungi veicolo");
            System.out.println("3. Rimuovi veicolo");
            System.out.println("4. Vendi veicolo");
            System.out.println("5. Fai benzina");
            System.out.println("6. Accendi veicolo");
            System.out.println("7. Spegni veicolo");
            System.out.println("8. Torna al menu principale");
            System.out.print("Scegli un'operazione: ");
            opzione = scanner.nextInt();
            scanner.nextLine();

            switch (opzione) {
                case 1:
                    concessionario.mostraVeicoli();
                    break;
                case 2:
                    aggiungiVeicolo(concessionario, scanner);
                    break;
                case 3:
                    rimuoviVeicolo(concessionario, scanner);
                    break;
                case 4:
                    vendiVeicolo(concessionario, scanner);
                    break;
                case 5:
                    faiBenzina(concessionario, scanner);
                    break;
                case 6:
                    accendiVeicolo(concessionario, scanner);
                    break;
                case 7:
                    spegniVeicolo(concessionario, scanner);
                    break;
                case 8:
                    System.out.println("Tornando al menu principale...");
                    break;
                default:
                    System.out.println("Operazione non valida.");
            }
        }
    }

    public static void aggiungiVeicolo(Concessionario concessionario, Scanner scanner) {
        System.out.print("Inserisci il tipo del veicolo (Automobile/Moto): ");
        String tipo = scanner.nextLine().toLowerCase();
        System.out.print("Inserisci la marca del veicolo: ");
        String marca = scanner.nextLine();
        System.out.print("Inserisci il modello del veicolo: ");
        String modello = scanner.nextLine();
        System.out.print("Inserisci l'anno del veicolo: ");
        int anno = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Inserisci la cilindrata del veicolo: ");
        double cilindrata = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Inserisci il prezzo del veicolo: ");
        double prezzo = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        switch (tipo){
            case "automobile":
                System.out.println("Inserisci il numero di porte: ");
                int numeroPorte = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Inserisci il tipo di carburante: ");
                String carburante = scanner.nextLine();
                try {
                    Automobile auto = new Automobile(marca, modello, anno, cilindrata, prezzo, numeroPorte, carburante);
                    concessionario.aggiungiVeicolo(auto);
                    break;
                } catch(Exception e) {
                    System.out.println("Error: " + e.getMessage());
            }
            case "moto":
                System.out.println("Inserisci il numero di ruote: ");
                int numeroRuote = scanner.nextInt();
                scanner.nextLine();
                try {
                    Moto moto = new Moto(marca, modello, anno, cilindrata, prezzo, numeroRuote);
                    concessionario.aggiungiVeicolo(moto);
                    break;
                } catch (Exception e){
                    System.out.println("Error: " + e.getMessage());
                }
        }
    }

    public static void rimuoviVeicolo(Concessionario concessionario, Scanner scanner) {
        System.out.print("Inserisci la marca del veicolo da rimuovere: ");
        String tipo = scanner.nextLine().toUpperCase();
        System.out.print("Inserisci il modello del veicolo da rimuovere: ");
        String modello = scanner.nextLine();
        try {
            Veicolo veicolo = concessionario.getVeicolo(tipo, modello);
            concessionario.rimuoviVeicolo(veicolo);
        } catch (Exception e){
            System.out.println("Error: "+ e.getMessage());
        }
    }

    public static void vendiVeicolo(Concessionario concessionario, Scanner scanner) {
        System.out.print("Inserisci la marca del veicolo da vendere: ");
        String tipo = scanner.nextLine();
        System.out.print("Inserisci il modello del veicolo da vendere: ");
        String modello = scanner.nextLine();
        try {
            concessionario.vendiVeicolo(tipo, modello);
        } catch (Exception e){
            System.out.println("Error" + e.getMessage());
        }
    }

    public static void faiBenzina(Concessionario concessionario, Scanner scanner){

        System.out.print("Inserisci la marca del veicolo per fare benzina: ");
        String tipo = scanner.nextLine().toUpperCase();
        System.out.print("Inserisci il modello del veicolo: ");
        String modello = scanner.nextLine();
        System.out.println("Inserisci quanti litri vuoi inserire");
        double litri = scanner.nextDouble();
        scanner.nextLine();
        try {
            Veicolo veicolo = concessionario.getVeicolo(tipo, modello);
            if (veicolo == null){
                throw new IllegalStateException("Veicolo non trovato");
            }
            veicolo.faiBenzina(litri);
        } catch (Exception e){
            System.out.println("Error: "+ e.getMessage());
        }
    }

    public static void accendiVeicolo(Concessionario concessionario, Scanner scanner){
        System.out.print("Inserisci la marca del veicolo da accendere: ");
        String tipo = scanner.nextLine().toUpperCase();
        System.out.print("Inserisci il modello del veicolo: ");
        String modello = scanner.nextLine();

        try {
            Veicolo veicolo = concessionario.getVeicolo(tipo, modello);
            if (veicolo == null){
                throw new IllegalStateException("Veicolo non trovato");
            }
            veicolo.Accendi();
        } catch (Exception e){
            System.out.println("Error: "+ e.getMessage());
        }
    }

    public static void spegniVeicolo(Concessionario concessionario, Scanner scanner){
        System.out.print("Inserisci la marca del veicolo da spegnere: ");
        String tipo = scanner.nextLine().toUpperCase();
        System.out.print("Inserisci il modello del veicolo: ");
        String modello = scanner.nextLine();

        try {
            Veicolo veicolo = concessionario.getVeicolo(tipo, modello);
            if (veicolo == null){
                throw new IllegalStateException("Veicolo non trovato");
            }
            veicolo.Spegni();
        } catch (Exception e){
            System.out.println("Error: "+ e.getMessage());
        }
    }

    public static void caricaSaldo(Utente utente, Scanner scanner){
        System.out.println("Inserisci il saldo da caricare: ");
        double saldo = scanner.nextDouble();
        scanner.nextLine();
        try {
            utente.setSaldo(saldo);
        } catch (Exception e){
            System.out.println("Error: "+ e.getMessage());
        }
    }

    public static void compraMacchina(Utente utente, Concessionario concessionario, Scanner scanner){
        concessionario.mostraVeicoli();
        System.out.print("Inserisci la marca del veicolo da comprare: ");
        String tipo = scanner.nextLine().toUpperCase();
        System.out.print("Inserisci il modello del veicolo: ");
        String modello = scanner.nextLine();
        try {
            Veicolo veicolo = concessionario.getVeicolo(tipo, modello);
            if (veicolo != null) {
                utente.acquistaVeicolo(veicolo);
                concessionario.rimuoviVeicolo(veicolo);
            } else {
                throw new IllegalStateException("Veicolo non trovato");
            }
        } catch (Exception e){
            System.out.println("Error: "+ e.getMessage());
        }
    }

}
