package Concessionario;
import java.util.ArrayList;
import java.util.List;

public class Utente {

    private String nome;
    private double saldo;
    private List<Veicolo> garage;

    public Utente(String nome){
        this.nome = nome;
        this.saldo = saldo;
        this.garage = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        if (saldo < 0){
            throw new IllegalStateException("Non puoi depositare valori negativi");
        } try {
            this.saldo += saldo;
            System.out.println("Deposito andato a buon fine, saldo: " + saldo);
        } catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void mostraGarage() {
        if (garage.isEmpty()) {
            System.out.println("Il garage è vuoto.");
        } else {
            for (Veicolo veicolo : garage) {
                try {
                    if (veicolo != null) {
                        System.out.println(veicolo.toString());
                    } else {
                        System.out.println("Veicolo nullo nel garage.");
                    }
                } catch (Exception e) {
                    System.out.println("Errore nel mostrare il veicolo: " + e.getMessage());
                }
            }
        }
    }


    public void aggiungiVeicoloGarage(Veicolo veicolo) {
        try {
            garage.add(veicolo);
            System.out.println("veicolo aggiunto con successo!");
        } catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void acquistaVeicolo(Veicolo veicolo){
        if (this.saldo > veicolo.getPrezzo()){
            try {
                this.saldo -= veicolo.getPrezzo();
                aggiungiVeicoloGarage(veicolo);
                System.out.println("Acquisto andato a buon fine, veicolo {" + veicolo.toString() + "}, saldo: " + saldo);
            } catch (Exception e){
                System.out.println("Error: " + e.getMessage());
            }
        } else {
            System.out.println("Saldo non disponibile");
        }
    }

}
