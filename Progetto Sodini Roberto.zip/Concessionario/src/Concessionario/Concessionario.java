package Concessionario;
import java.util.ArrayList;
import java.util.List;

public class Concessionario {

    //variable type List for vehicles, contains istances of Vehicle, Automobile or Moto
    private List<Veicolo> veicoli;

    public Concessionario() {
        veicoli = new ArrayList<>();
    }


    public void aggiungiVeicolo(Veicolo veicolo) {
        try {
            veicoli.add(veicolo);
            System.out.println("veicolo aggiunto con successo!");
        } catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void rimuoviVeicolo(Veicolo veicolo) {
        try {
            veicoli.remove(veicolo);
            System.out.println("Veicolo rimosso.");
        } catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void mostraVeicoli() {
            for (Veicolo veicolo : veicoli) {
                try {
                System.out.println(veicolo.toString());
            } catch (Exception e) {
                    System.out.println("Errore nel mostrare il veicolo" + e.getMessage());
                }
          }
    }

    public Veicolo getVeicolo(String tipo, String modello) {
        for (Veicolo veicolo : veicoli) {
            try {
                if (veicolo.getTipo().equalsIgnoreCase(tipo) & veicolo.getModello().equalsIgnoreCase(modello)) {
                    System.out.println("Veicolo trovato: " + veicolo.toString());
                    return veicolo;
                }
            } catch (NullPointerException e) {
                System.out.println("Veicolo non trovato" + e.getMessage());
            } catch (Exception e) {
                System.out.println("Errore durante la ricerca del veicolo" + e.getMessage());
            }
        }
        return null;
    }


    public void vendiVeicolo(String tipo, String modello) {
        boolean trovato = false;
        for (Veicolo veicolo : veicoli) {
            try {
                if (veicolo.getTipo().equalsIgnoreCase(tipo) & veicolo.getModello().equalsIgnoreCase(modello)) {
                    System.out.println("Veicolo venduto: " + veicolo.toString());
                    rimuoviVeicolo(veicolo);
                    trovato = true;
                    break;
                }
            }catch (NullPointerException e) {
                System.out.println("Veicolo non trovato" + e.getMessage());
            } catch (Exception e){
                System.out.println("Errore durante la ricerca del veicolo"+ e.getMessage());
            }
        }
        if (!trovato){
            System.out.println("Veicolo" + tipo +", " + modello +" non trovato");
        }
    }

}