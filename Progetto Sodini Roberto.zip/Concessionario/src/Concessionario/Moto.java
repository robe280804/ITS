package Concessionario;

public class Moto extends Veicolo {

    private int numeroRuote;

    public Moto(String marca, String modello, int anno, double cilindrata, double prezzo, int numeroRuote) {
        super(marca, modello, anno, cilindrata, prezzo);
        this.numeroRuote = numeroRuote;
    }

    public int getNumeroRuote() {
        return numeroRuote;
    }

    public String toString() {
        return super.toString() + ", numero di ruote: " + numeroRuote ;
    }


}
