package Concessionario;

public class Automobile extends Veicolo {


    private int numeroPorte;
    private String TipoCarburante;

    public Automobile(String marca, String modello, int anno, double cilindrata, double prezzo, int numeroPorte, String TipoCarburante) {
        super(marca, modello, anno, cilindrata, prezzo);
        this.numeroPorte = numeroPorte;
        this.TipoCarburante = TipoCarburante;
    }

    public int getNumeroPorte() {
        return numeroPorte;
    }

    public String carburante() {
        return TipoCarburante;
    }

    public String toString() {
        return super.toString() + ", numero di porte: " + numeroPorte + ", tipo di carburante: " + TipoCarburante;
    }



}

